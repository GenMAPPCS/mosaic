from distutils.core import setup
import py2exe

#setup(console=['GO_Elite.py'])

setup(windows=[{"script":'GO_Elite.py',"icon_resources":[(1,"goelite.ico")]}])


    